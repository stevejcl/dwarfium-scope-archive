#error "Since version 0.3, astropy.wcs public API should be imported as \"astropy_wcs/astropy_wcs_api.h"
